package com.thrive.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import org.springframework.jdbc.core.RowMapper;

import com.thrive.domain.Persondimensiondomain;

public class Persondimensionmapper implements RowMapper<Persondimensiondomain>{ 
	@Override
	public Persondimensiondomain mapRow(ResultSet rs, int rowNum) throws SQLException {
		Persondimensiondomain persondimensionmap = new Persondimensiondomain();
		
		persondimensionmap.setPerson_key(rs.getLong("person_key"));
		persondimensionmap.setFirst_name(rs.getString("first_name"));
		persondimensionmap.setFull_name(rs.getString("full_name"));
		persondimensionmap.setLast_name(rs.getString("last_name"));
		persondimensionmap.setPerson_id(UUID.fromString(rs.getString("person_id")));
		
		return persondimensionmap;
	
	}

}
