package com.thrive.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import org.springframework.jdbc.core.RowMapper;

import com.thrive.domain.Processdimensiondomain;

public class Processdimensionmapper implements RowMapper<Processdimensiondomain>
{
	@Override
	public Processdimensiondomain mapRow(ResultSet rs, int rowNum) throws SQLException {
		Processdimensiondomain processdimensionmap = new Processdimensiondomain();
		
		processdimensionmap.setProcess_key(rs.getLong("process_key"));
		processdimensionmap.setDescription_2(rs.getString("description_2"));
		processdimensionmap.setId(UUID.fromString(rs.getString("id")));
		processdimensionmap.setName(rs.getString("name"));
		
		
		return processdimensionmap;
	
	}

}
