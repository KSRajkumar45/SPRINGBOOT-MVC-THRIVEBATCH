package com.thrive.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import org.springframework.jdbc.core.RowMapper;

import com.thrive.domain.Classroomdimensiondomain;
import com.thrive.domain.TrainingDashboardPersons;

public class CRDMapper implements RowMapper<Classroomdimensiondomain>{
	
	@Override
	public Classroomdimensiondomain mapRow(ResultSet rs, int rowNum) throws SQLException {
		Classroomdimensiondomain classroomdimensionmap = new Classroomdimensiondomain();
		
		classroomdimensionmap.setClass_key(rs.getLong("class_key"));
		classroomdimensionmap.setDescription_2(rs.getString("description_2"));
		classroomdimensionmap.setId(UUID.fromString(rs.getString("id")));
		classroomdimensionmap.setName(rs.getString("name"));
		
		return classroomdimensionmap;
	
	}

}
