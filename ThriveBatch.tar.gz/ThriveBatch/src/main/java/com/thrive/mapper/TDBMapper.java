package com.thrive.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import org.springframework.jdbc.core.RowMapper;

import com.thrive.domain.TrainingDashboardPersons;

public class TDBMapper implements RowMapper<TrainingDashboardPersons> {

		@Override
		public TrainingDashboardPersons mapRow(ResultSet rs, int rowNum) throws SQLException {
			TrainingDashboardPersons dashboardmap = new TrainingDashboardPersons();
			dashboardmap.setId(UUID.fromString(rs.getString("id")));			
			dashboardmap.setCategory(rs.getString("category"));
			dashboardmap.setClass_id(UUID.fromString(rs.getString("class_id")));
			dashboardmap.setPerson_id(UUID.fromString(rs.getString("person_id")));
			dashboardmap.setTraining_date(rs.getDate("training_date"));
			//System.out.println("rs.getString(process_id)-      > >> >> "+rs.getString("process_id"));
			if(rs.getString("process_id")!=null){
				dashboardmap.setProcess_id(UUID.fromString(rs.getString("process_id")));		
			}else{
				System.out.println("Do nothing");
			}
				
			
			return dashboardmap;
		
		}
}
