package com.thrive.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import org.springframework.jdbc.core.RowMapper;

import com.thrive.domain.Training_dashboard_Factdomain;

public class TDFMapper implements RowMapper<Training_dashboard_Factdomain>  {
	
	@Override
	public Training_dashboard_Factdomain mapRow(ResultSet rs, int rowNum) throws SQLException {
		Training_dashboard_Factdomain dashboardfactmap = new Training_dashboard_Factdomain();
		
		dashboardfactmap.setTraining_dashboard_key(rs.getLong("training_dashboard_key"));
		dashboardfactmap.setClass_key(rs.getInt("class_key"));
		dashboardfactmap.setDate_key(rs.getInt("date_key"));
		dashboardfactmap.setPerson_key(rs.getInt("person_key"));
		dashboardfactmap.setProcess_key(rs.getInt("process_key"));
		dashboardfactmap.setTraining_attendance(rs.getString("training_attendance"));
		dashboardfactmap.setTraining_id(UUID.fromString(rs.getString("training_id")));
		return dashboardfactmap;

}
}