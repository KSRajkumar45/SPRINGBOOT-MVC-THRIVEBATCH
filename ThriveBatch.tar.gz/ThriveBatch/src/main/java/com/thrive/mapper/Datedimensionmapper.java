package com.thrive.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.thrive.domain.Datedimensiondomain;

public class Datedimensionmapper implements RowMapper<Datedimensiondomain>{ 
	@Override
	public Datedimensiondomain mapRow(ResultSet rs, int rowNum) throws SQLException {
		Datedimensiondomain datedimensionmap = new Datedimensiondomain();
		
		datedimensionmap.setDate_key(rs.getInt("date_key"));		
		datedimensionmap.setDate(rs.getDate("date"));
		datedimensionmap.setDay_name(rs.getString("day_name"));
		datedimensionmap.setDay_of_month(rs.getInt("day_of_month"));
		datedimensionmap.setDay_of_week(rs.getInt("day_of_week"));
		datedimensionmap.setDay_of_week_in_month(rs.getInt("day_of_week_in_month"));
		datedimensionmap.setDay_of_week_in_year(rs.getInt("day_of_week_in_year"));
		datedimensionmap.setDay_of_year(rs.getInt("day_of_year"));
		datedimensionmap.setFirst_day_of_month(rs.getDate("first_day_of_month"));
		datedimensionmap.setFirst_day_of_quarter(rs.getDate("first_day_of_quarter"));
		datedimensionmap.setFirst_day_of_year(rs.getDate("first_day_of_year"));
		datedimensionmap.setHoliday_name(rs.getString("holiday_name"));
		datedimensionmap.setIs_holiday(rs.getBoolean("is_holiday"));
		datedimensionmap.setIs_weekday(rs.getBoolean("is_weekday"));
		datedimensionmap.setIso_date(rs.getDate("iso_date"));
		datedimensionmap.setLast_day_of_month(rs.getDate("last_day_of_month"));
		datedimensionmap.setLast_day_of_quarter(rs.getDate("last_day_of_quarter"));
		datedimensionmap.setLast_day_of_year(rs.getDate("last_day_of_year"));
		datedimensionmap.setMonth(rs.getInt("month"));	
		datedimensionmap.setMonth_name(rs.getString("month_name"));
		datedimensionmap.setMonth_of_quarter(rs.getInt("month_of_quarter"));
		datedimensionmap.setQuarter(rs.getString("quarter"));
		datedimensionmap.setWeek_of_month(rs.getInt("week_of_month"));	
		datedimensionmap.setWeek_of_quarter(rs.getInt("week_of_quarter"));	
		datedimensionmap.setWeek_of_year(rs.getInt("week_of_year"));	
		datedimensionmap.setYear(rs.getInt("year"));	
		
		
		
		
		return datedimensionmap;

}
}