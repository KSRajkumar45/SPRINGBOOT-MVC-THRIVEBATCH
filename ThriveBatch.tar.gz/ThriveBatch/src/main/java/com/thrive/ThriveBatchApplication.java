package com.thrive;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.thrive.domain.Classroomdimensiondomain;
import com.thrive.domain.Datedimensiondomain;
import com.thrive.domain.Persondimensiondomain;
import com.thrive.domain.Processdimensiondomain;
import com.thrive.domain.TrainingDashboardPersons;
import com.thrive.service.Training_dashboard_person;

public class ThriveBatchApplication {

	private static Training_dashboard_person dashboardpersonservice;

	public static void main(String[] args) throws Exception {

		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring-config.xml");
		dashboardpersonservice = (Training_dashboard_person) context.getBean("training_dashboard_person");

		// Getting Training dashboard person data

		ArrayList<TrainingDashboardPersons> dashboardpersons = dashboardpersonservice.getdata();
		//System.out.println("TrainingDashboardPersons data------>"+dashboardpersons.toString());
		
		 // Getting person key using person key
		
		
		for (TrainingDashboardPersons idGet : dashboardpersons) {
			System.out.println("class_id ");
			UUID classid = idGet.getClass_id();
			System.out.println(classid);
		
			ArrayList<Classroomdimensiondomain> classroomdimension = dashboardpersonservice.getclasskey(classid);
			System.out.println("classroomdimensionclasskey data ------>"+classroomdimension.toString());
			System.out.println("classkey ");
		
			for (Classroomdimensiondomain Classkey : classroomdimension) {
				long ckey = Classkey.getClass_key();
				System.out.println(ckey);
					
			}
		
		
		// Getting person key using person id
				System.out.println("person_id ");
				UUID personid = idGet.getPerson_id();
				System.out.println(personid);

				ArrayList<Persondimensiondomain> persondimensionkey = dashboardpersonservice.getpersonkey(personid);
				System.out.println("peronkey data ------>"+persondimensionkey.toString());
				System.out.println("personkey");

				for (Persondimensiondomain Personkey : persondimensionkey) {
					long personkey = Personkey.getPerson_key();
					System.out.println(personkey);
				  	}
		
                // Getting process key using process key
				System.out.println("process_id ");
				UUID processid = idGet.getProcess_id();
				System.out.println(processid);
				
				ArrayList<Processdimensiondomain> processdimensionkey = dashboardpersonservice.getprocesskey(processid);
				System.out.println("processkey data ------>"+processdimensionkey.toString());
				System.out.println("processkey");

				for (Processdimensiondomain Processkey : processdimensionkey) {
					long processkey = Processkey.getProcess_key();
					System.out.println(processkey);
				} 	
		
				 //Getting date key using date
				System.out.println("date ");
				Date date = idGet.getTraining_date();
				System.out.println(date);
				
				ArrayList<Datedimensiondomain> dashboardfactdatekey = dashboardpersonservice.getdatekey(date);
				System.out.println("datekey data ------>"+dashboardfactdatekey.toString());
				System.out.println("datekey");

				for (Datedimensiondomain Datekey : dashboardfactdatekey) {
					long datekey = Datekey.getDate_key();
					System.out.println(datekey);
			     	}
	}
			
		
	}
		}
	


