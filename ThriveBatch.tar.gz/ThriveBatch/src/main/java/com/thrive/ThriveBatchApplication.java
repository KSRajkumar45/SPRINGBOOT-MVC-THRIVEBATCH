package com.thrive;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.thrive.domain.Classroomdimensiondomain;
import com.thrive.domain.Datedimensiondomain;
import com.thrive.domain.Persondimensiondomain;
import com.thrive.domain.Processdimensiondomain;
import com.thrive.domain.TrainingDashboardPersons;
import com.thrive.domain.Training_dashboard_Factdomain;
import com.thrive.service.Training_dashboard_person;

public class ThriveBatchApplication {

	private static Training_dashboard_person dashboardpersonservice;

	public static void main(String[] args) throws Exception {

		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring-config.xml");
		dashboardpersonservice = (Training_dashboard_person) context.getBean("training_dashboard_person");

		// Getting Training dashboard person data

		ArrayList<TrainingDashboardPersons> dashboardpersons = dashboardpersonservice.getdata();
		// System.out.println("TrainingDashboardPersons
		// data------>"+dashboardpersons.toString());

		// Getting person key using person key

		ArrayList<Training_dashboard_Factdomain> finaldatas = new ArrayList<Training_dashboard_Factdomain>();

		for (TrainingDashboardPersons idGet : dashboardpersons) {
		
			long PersonKey = 0;
			long ProcessKey = 0;
			long DateKey = 0;
			long TrainingKey = 0;
			long  ClassKey = 0;
			
			UUID classid = idGet.getClass_id();
			if (classid != null) {

				ArrayList<Classroomdimensiondomain> classroomdimension = dashboardpersonservice.getclasskey(classid);
				System.out.println("classroomdimensionclasskey data ------>" + classroomdimension.toString());

				for (Classroomdimensiondomain Classkey : classroomdimension) {
					UUID Classid = Classkey.getId();
					System.out.println("class_id ");
					System.out.println(Classid);
					 ClassKey = Classkey.getClass_key();
					System.out.println("classkey ");
					System.out.println( ClassKey);

				}
			}

			// Getting person key using person id

			UUID personid = idGet.getPerson_id();
			if (personid != null) {

				ArrayList<Persondimensiondomain> persondimensionkey = dashboardpersonservice.getpersonkey(personid);
				System.out.println("peronkey data ------>" + persondimensionkey.toString());

				for (Persondimensiondomain Personkey : persondimensionkey) {
					UUID Personid = Personkey.getPerson_id();
					System.out.println("person_id ");
					System.out.println(Personid);
					 PersonKey = Personkey.getPerson_key();
					System.out.println("personkey");
					System.out.println(PersonKey);
				}
			}

			// Getting process key using process key

			UUID processid = idGet.getProcess_id();
			if (processid != null) {
				System.out.println(processid);

				ArrayList<Processdimensiondomain> processdimensionkey = dashboardpersonservice.getprocesskey(processid);
				System.out.println("processkey data ------>" + processdimensionkey.toString());

				for (Processdimensiondomain Processkey : processdimensionkey) {
					UUID Processid = Processkey.getId();
					System.out.println("processid");
					System.out.println(processid);
					 ProcessKey = Processkey.getProcess_key();
					System.out.println("processkey");
					System.out.println(ProcessKey);
				}
			}
			// Getting date key using date

			Date date = idGet.getTraining_date();
			if (date != null) {

				ArrayList<Datedimensiondomain> dashboardfactdatekey = dashboardpersonservice.getdatekey(date);
				System.out.println("datekey data ------>" + dashboardfactdatekey.toString());

				for (Datedimensiondomain Datekey : dashboardfactdatekey) {
					Date date1 = Datekey.getDate();
					System.out.println("date ");
					System.out.println(date1);
					 DateKey = Datekey.getDate_key();
					System.out.println("datekey");
					System.out.println(DateKey);
				}
			}
			UUID trainingid = idGet.getId();
			if (trainingid != null) {
				ArrayList<Training_dashboard_Factdomain> trainingkey = dashboardpersonservice
						.gettrainingkey(trainingid);
				System.out.println("datekey data ------>" + trainingkey.toString());

				for (Training_dashboard_Factdomain Trainingkey : trainingkey) {
					UUID Tid = Trainingkey.getTraining_id();
					System.out.println("trainingid ");
					System.out.println(Tid);
					 TrainingKey = Trainingkey.getTraining_dashboard_key();
					System.out.println("trainingkey");
					System.out.println(TrainingKey);
				}
			}
			Training_dashboard_Factdomain data = new Training_dashboard_Factdomain();
			data.setClass_key((int) ClassKey);
			data.setPerson_key((int) PersonKey);
			data.setProcess_key((int) ProcessKey);
			data.setDate_key((int) DateKey);
			data.setTraining_dashboard_key(TrainingKey);
			
			finaldatas.add(data);
		}
		System.err.println("The final data's has been added in the arraylist------>" + finaldatas.toString());
	}
}
