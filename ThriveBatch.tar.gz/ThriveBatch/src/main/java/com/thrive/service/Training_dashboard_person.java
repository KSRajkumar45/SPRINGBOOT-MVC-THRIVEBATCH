package com.thrive.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.thrive.dao.Training_dashboard_person_DAO;
import com.thrive.domain.Classroomdimensiondomain;
import com.thrive.domain.Datedimensiondomain;
import com.thrive.domain.Persondimensiondomain;
import com.thrive.domain.Processdimensiondomain;
import com.thrive.domain.TrainingDashboardPersons;

@Component
public class Training_dashboard_person {
	
	@Autowired
	private Training_dashboard_person_DAO  dashboardpersondao;
	
	
	public ArrayList<TrainingDashboardPersons> getdata() throws Exception {
				ArrayList<TrainingDashboardPersons> dashboardpersons = new ArrayList();
		dashboardpersons = dashboardpersondao.getdata();
			return dashboardpersons;
	}
	
	public ArrayList<Classroomdimensiondomain> getclasskey(UUID classid) throws Exception {
		ArrayList<Classroomdimensiondomain> classkey = new ArrayList();
		classkey=dashboardpersondao.getclasskey(classid);
		return classkey;
	}
	
	public ArrayList<Persondimensiondomain> getpersonkey(UUID personid) throws Exception {
		ArrayList<Persondimensiondomain> personkey = new ArrayList();
		personkey=dashboardpersondao.getpersonkey(personid);
		return personkey;
	}
	
	public ArrayList<Processdimensiondomain> getprocesskey(UUID processid) throws Exception {
		ArrayList<Processdimensiondomain> processkey = new ArrayList();
		processkey=dashboardpersondao.getprocesskey(processid);
		return processkey;
	}
	
	public ArrayList<Datedimensiondomain> getdatekey(Date date) throws Exception {
		ArrayList<Datedimensiondomain> datekey = new ArrayList();
		datekey=dashboardpersondao.getdatekey(date);
		return datekey;
	}

}