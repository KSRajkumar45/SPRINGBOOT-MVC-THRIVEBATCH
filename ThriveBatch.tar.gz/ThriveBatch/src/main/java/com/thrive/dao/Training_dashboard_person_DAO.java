package com.thrive.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.ListIterator;
import java.util.UUID;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import com.thrive.domain.Classroomdimensiondomain;
import com.thrive.domain.Datedimensiondomain;
import com.thrive.domain.Persondimensiondomain;
import com.thrive.domain.Processdimensiondomain;
import com.thrive.domain.TrainingDashboardPersons;
import com.thrive.mapper.CRDMapper;
import com.thrive.mapper.Datedimensionmapper;
import com.thrive.mapper.Persondimensionmapper;
import com.thrive.mapper.Processdimensionmapper;
import com.thrive.mapper.TDBMapper;

@Component
public class Training_dashboard_person_DAO {
	
	private DataSource datasource;
	private NamedParameterJdbcTemplate jdbctemplate;
	
	@Value("${getall.sql}")
	private String getall;	
	
	public DataSource getDatasource() {	
		return datasource;
	}
	
	@Resource(name="datasource")
    
	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
		this.jdbctemplate = new NamedParameterJdbcTemplate(datasource);
	}

	public NamedParameterJdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}

	public void setJdbctemplate(NamedParameterJdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	
	@Value("${getclasskey.sql}")
	private String getclasskey;
	
	@Value("${getpersonkey.sql}")
	private String getpersonkey;
	
	@Value("${getprocesskey.sql}")
	private String getprocesskey;	
	
	@Value("${getdatekey.sql}")
	private String getdatekey;
     
	public ArrayList<TrainingDashboardPersons> getdata() throws Exception {
	//add code here
		MapSqlParameterSource parameters;
		
		parameters = new MapSqlParameterSource();
		TDBMapper dashboardpersonsmapper = new TDBMapper();
		ArrayList<TrainingDashboardPersons> dashboardpersonsmapperList = (ArrayList<TrainingDashboardPersons>) this.jdbctemplate.query(getall, parameters, dashboardpersonsmapper);
		
		if(dashboardpersonsmapperList.size()<1){
			throw new Exception("training endpoint  for project   was not found..!");
		}
		
		return dashboardpersonsmapperList;
		
	}
	
	public ArrayList<Classroomdimensiondomain> getclasskey(UUID classid) throws Exception {
         MapSqlParameterSource parameters= new MapSqlParameterSource();	
         parameters.addValue("id", classid);
         CRDMapper classroommapper = new CRDMapper();
 		ArrayList<Classroomdimensiondomain> classroommapperList = (ArrayList<Classroomdimensiondomain>) this.jdbctemplate.query(getclasskey, parameters, classroommapper);
 		/*
 		if(classroommapperList.size()<1){
 			throw new Exception("training endpoint  for project   was not found..!");
 		}
 		*/
 		return classroommapperList;
 		
 	}
	
	public ArrayList<Persondimensiondomain> getpersonkey(UUID personid) throws Exception {
        MapSqlParameterSource parameters= new MapSqlParameterSource();	
        parameters.addValue("id", personid);
        Persondimensionmapper personkeymapper = new Persondimensionmapper();
		ArrayList<Persondimensiondomain> personkeymapperlist = (ArrayList<Persondimensiondomain>) this.jdbctemplate.query(getpersonkey, parameters, personkeymapper);
		/*
		if(personkeymapperlist.size()<1){
			throw new Exception("training endpoint  for project   was not found..!");
		}*/
		
		return personkeymapperlist;
		
	}
	
	public ArrayList<Processdimensiondomain> getprocesskey(UUID processid) throws Exception {
        MapSqlParameterSource parameters= new MapSqlParameterSource();	
        parameters.addValue("id", processid);
        Processdimensionmapper processkeymapper = new Processdimensionmapper();
		ArrayList<Processdimensiondomain> processkeytmapperlist = (ArrayList<Processdimensiondomain>) this.jdbctemplate.query(getprocesskey, parameters, processkeymapper);
		if(processkeytmapperlist.size()<1){
			return processkeytmapperlist;
		}
		return processkeytmapperlist;
		
	}
	
	public ArrayList<Datedimensiondomain> getdatekey(Date date) throws Exception {
        MapSqlParameterSource parameters= new MapSqlParameterSource();	
        parameters.addValue("date", date);
        Datedimensionmapper datekeymapper = new Datedimensionmapper();
		ArrayList<Datedimensiondomain> datekeymapperlist = (ArrayList<Datedimensiondomain>) this.jdbctemplate.query(getdatekey, parameters, datekeymapper);
		
		if(datekeymapperlist.size()<1)
		{
			return datekeymapperlist;	
		}
		
		return datekeymapperlist;
		}
}
	
	
	

