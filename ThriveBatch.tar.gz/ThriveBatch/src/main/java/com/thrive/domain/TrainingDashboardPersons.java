package com.thrive.domain;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Entity;
@Entity
public class TrainingDashboardPersons {
	
	private UUID id;
	private String category;
	private UUID class_id;
	private UUID person_id;
	private UUID process_id;
	private Date training_date;
	
	public TrainingDashboardPersons()
	{
	}
	
	public UUID getId() {
		return id;
	}
	public void setId(UUID id) {
		this.id = id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public UUID getClass_id() {
		return class_id;
	}
	public void setClass_id(UUID class_id) {
		this.class_id = class_id;
	}
	public UUID getPerson_id() {
		return person_id;
	}
	public void setPerson_id(UUID person_id) {
		this.person_id = person_id;
	}
	public UUID getProcess_id() {
		return process_id;
	}
	public void setProcess_id(UUID process_id) {
		this.process_id = process_id;
	}

	public Date getTraining_date() {
		return training_date;
	}

	public void setTraining_date(Date training_date) {
		this.training_date = training_date;
	}

	@Override
	public String toString() {
		return "TrainingDashboardPersons [id=" + id + ", category=" + category + ", class_id=" + class_id
				+ ", person_id=" + person_id + ", process_id=" + process_id + ", training_date=" + training_date + "]";
	}
	
	
	

}
