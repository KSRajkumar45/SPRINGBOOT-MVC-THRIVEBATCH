package com.thrive.domain;

import java.util.UUID;

import javax.persistence.Entity;
@Entity
public class Processdimensiondomain {
	long process_key;
	  String description_2;
	  UUID id;
	  String name;
	  public Processdimensiondomain()
	  {
		  
	  }
	public long getProcess_key() {
		return process_key;
	}
	public void setProcess_key(long process_key) {
		this.process_key = process_key;
	}
	public String getDescription_2() {
		return description_2;
	}
	public void setDescription_2(String description_2) {
		this.description_2 = description_2;
	}
	public UUID getId() {
		return id;
	}
	public void setId(UUID id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Processdimensiondomain [process_key=" + process_key + ", description_2=" + description_2 + ", id=" + id
				+ ", name=" + name + "]";
	}
	

}
