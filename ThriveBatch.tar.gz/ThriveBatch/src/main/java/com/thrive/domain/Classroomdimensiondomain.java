package com.thrive.domain;

import java.util.UUID;

import javax.persistence.Entity;
@Entity
public class Classroomdimensiondomain {
  private long class_key;
  private String description_2;
  private UUID id;
  private String name;
  public Classroomdimensiondomain()
  {
	  
  }
 
public long getClass_key() {
	return class_key;
}
public void setClass_key(long class_key) {
	this.class_key = class_key;
}
public String getDescription_2() {
	return description_2;
}
public void setDescription_2(String description_2) {
	this.description_2 = description_2;
}
public UUID getId() {
	return id;
}
public void setId(UUID id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

@Override
public String toString() {
	return "Classroomdimensiondomain [class_key=" + class_key + ", description_2=" + description_2 + ", id=" + id
			+ ", name=" + name + "]";
}

}
