package com.thrive.domain;

import java.util.UUID;

public class Training_dashboard_Factdomain {
	private long training_dashboard_key;
	private int class_key;
	private int date_key;
	private int person_key;
	private int process_key;
	private String training_attendance;
	private UUID training_id;
	
	public Training_dashboard_Factdomain()
	{
		
	}
	public long getTraining_dashboard_key() {
		return training_dashboard_key;
	}
	public void setTraining_dashboard_key(long training_dashboard_key) {
		this.training_dashboard_key = training_dashboard_key;
	}
	public int getClass_key() {
		return class_key;
	}
	public void setClass_key(int class_key) {
		this.class_key = class_key;
	}
	public int getDate_key() {
		return date_key;
	}
	public void setDate_key(int date_key) {
		this.date_key = date_key;
	}
	public int getPerson_key() {
		return person_key;
	}
	public void setPerson_key(int person_key) {
		this.person_key = person_key;
	}
	public int getProcess_key() {
		return process_key;
	}
	public void setProcess_key(int process_key) {
		this.process_key = process_key;
	}
	public String getTraining_attendance() {
		return training_attendance;
	}
	public void setTraining_attendance(String training_attendance) {
		this.training_attendance = training_attendance;
	}
	public UUID getTraining_id() {
		return training_id;
	}
	public void setTraining_id(UUID training_id) {
		this.training_id = training_id;
	}
	@Override
	public String toString() {
		return "Training_dashboard_Factdomain [training_dashboard_key=" + training_dashboard_key + ", class_key="
				+ class_key + ", date_key=" + date_key + ", person_key=" + person_key + ", process_key=" + process_key
				+ ", training_attendance=" + training_attendance + ", training_id=" + training_id + "]";
	}
	

}
