package com.thrive.domain;

import java.util.Date;

import javax.persistence.Entity;

@Entity
public class Datedimensiondomain {
	private int date_key;
	 private Date date;
	 private String day_name;
	 private int day_of_month;
	 private int day_of_week;
	 private int day_of_week_in_month;
	 private int day_of_week_in_year;
	 private int day_of_year;
	 private  Date first_day_of_month;
	 private Date first_day_of_quarter;
	 private Date first_day_of_year;
	 private  String holiday_name;
	 private  boolean is_holiday;
	 private  boolean is_weekday;
	 private Date iso_date;
	 private  Date last_day_of_month;
	 private  Date last_day_of_quarter;
	 private  Date last_day_of_year;
	 private int month;
	 private  String month_name;
	 private  int month_of_quarter;
	  private  String quarter;
	  private int week_of_month;
	  private int week_of_quarter;
	  private  int week_of_year;
	  private  int year;
public Datedimensiondomain()
{
	
}
	
	 public int getDate_key() {
		return date_key;
	}
	public void setDate_key(int date_key) {
		this.date_key = date_key;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDay_name() {
		return day_name;
	}
	public void setDay_name(String day_name) {
		this.day_name = day_name;
	}
	public int getDay_of_month() {
		return day_of_month;
	}
	public void setDay_of_month(int day_of_month) {
		this.day_of_month = day_of_month;
	}
	public int getDay_of_week() {
		return day_of_week;
	}
	public void setDay_of_week(int day_of_week) {
		this.day_of_week = day_of_week;
	}
	public int getDay_of_week_in_month() {
		return day_of_week_in_month;
	}
	public void setDay_of_week_in_month(int day_of_week_in_month) {
		this.day_of_week_in_month = day_of_week_in_month;
	}
	public int getDay_of_week_in_year() {
		return day_of_week_in_year;
	}
	public void setDay_of_week_in_year(int day_of_week_in_year) {
		this.day_of_week_in_year = day_of_week_in_year;
	}
	public int getDay_of_year() {
		return day_of_year;
	}
	public void setDay_of_year(int day_of_year) {
		this.day_of_year = day_of_year;
	}
	public Date getFirst_day_of_month() {
		return first_day_of_month;
	}
	public void setFirst_day_of_month(Date first_day_of_month) {
		this.first_day_of_month = first_day_of_month;
	}
	public Date getFirst_day_of_quarter() {
		return first_day_of_quarter;
	}
	public void setFirst_day_of_quarter(Date first_day_of_quarter) {
		this.first_day_of_quarter = first_day_of_quarter;
	}
	public Date getFirst_day_of_year() {
		return first_day_of_year;
	}
	public void setFirst_day_of_year(Date first_day_of_year) {
		this.first_day_of_year = first_day_of_year;
	}
	public String getHoliday_name() {
		return holiday_name;
	}
	public void setHoliday_name(String holiday_name) {
		this.holiday_name = holiday_name;
	}
	public boolean isIs_holiday() {
		return is_holiday;
	}
	public void setIs_holiday(boolean is_holiday) {
		this.is_holiday = is_holiday;
	}
	public boolean isIs_weekday() {
		return is_weekday;
	}
	public void setIs_weekday(boolean is_weekday) {
		this.is_weekday = is_weekday;
	}
	public Date getIso_date() {
		return iso_date;
	}
	public void setIso_date(Date iso_date) {
		this.iso_date = iso_date;
	}
	public Date getLast_day_of_month() {
		return last_day_of_month;
	}
	public void setLast_day_of_month(Date last_day_of_month) {
		this.last_day_of_month = last_day_of_month;
	}
	public Date getLast_day_of_quarter() {
		return last_day_of_quarter;
	}
	public void setLast_day_of_quarter(Date last_day_of_quarter) {
		this.last_day_of_quarter = last_day_of_quarter;
	}
	public Date getLast_day_of_year() {
		return last_day_of_year;
	}
	public void setLast_day_of_year(Date last_day_of_year) {
		this.last_day_of_year = last_day_of_year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public String getMonth_name() {
		return month_name;
	}
	public void setMonth_name(String month_name) {
		this.month_name = month_name;
	}
	public int getMonth_of_quarter() {
		return month_of_quarter;
	}
	public void setMonth_of_quarter(int month_of_quarter) {
		this.month_of_quarter = month_of_quarter;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public int getWeek_of_month() {
		return week_of_month;
	}
	public void setWeek_of_month(int week_of_month) {
		this.week_of_month = week_of_month;
	}
	public int getWeek_of_quarter() {
		return week_of_quarter;
	}
	public void setWeek_of_quarter(int week_of_quarter) {
		this.week_of_quarter = week_of_quarter;
	}
	public int getWeek_of_year() {
		return week_of_year;
	}
	public void setWeek_of_year(int week_of_year) {
		this.week_of_year = week_of_year;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	@Override
	public String toString() {
		return "Datedimensiondomain [date_key=" + date_key + ", date=" + date + ", day_name=" + day_name
				+ ", day_of_month=" + day_of_month + ", day_of_week=" + day_of_week + ", day_of_week_in_month="
				+ day_of_week_in_month + ", day_of_week_in_year=" + day_of_week_in_year + ", day_of_year=" + day_of_year
				+ ", first_day_of_month=" + first_day_of_month + ", first_day_of_quarter=" + first_day_of_quarter
				+ ", first_day_of_year=" + first_day_of_year + ", holiday_name=" + holiday_name + ", is_holiday="
				+ is_holiday + ", is_weekday=" + is_weekday + ", iso_date=" + iso_date + ", last_day_of_month="
				+ last_day_of_month + ", last_day_of_quarter=" + last_day_of_quarter + ", last_day_of_year="
				+ last_day_of_year + ", month=" + month + ", month_name=" + month_name + ", month_of_quarter="
				+ month_of_quarter + ", quarter=" + quarter + ", week_of_month=" + week_of_month + ", week_of_quarter="
				+ week_of_quarter + ", week_of_year=" + week_of_year + ", year=" + year + "]";
	}

}
