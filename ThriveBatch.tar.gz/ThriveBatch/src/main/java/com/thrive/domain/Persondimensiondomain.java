package com.thrive.domain;

import java.util.UUID;

import javax.persistence.Entity;
@Entity
public class Persondimensiondomain {
	  private long person_key;
	  private String first_name;
	  private String full_name;
	  private String last_name;
	  private UUID person_id;
	  public Persondimensiondomain()
	  {
		  
	  }
	public long getPerson_key() {
		return person_key;
	}
	public void setPerson_key(long person_key) {
		this.person_key = person_key;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public UUID getPerson_id() {
		return person_id;
	}
	public void setPerson_id(UUID person_id) {
		this.person_id = person_id;
	}
	@Override
	public String toString() {
		return "Persondimensiondomain [person_key=" + person_key + ", first_name=" + first_name + ", full_name="
				+ full_name + ", last_name=" + last_name + ", person_id=" + person_id + "]";
	}
	  

}
